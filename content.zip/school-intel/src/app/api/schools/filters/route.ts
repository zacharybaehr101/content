import { NextResponse } from 'next/server';
import { fetchFilterOptions } from '@/lib/sheets';

export const runtime = 'nodejs';

/**
 * GET /api/schools/filters
 *
 * Returns all unique values for each filterable field.
 * Public endpoint — no auth required.
 * Cached for 6 hours via ISR.
 */
export async function GET() {
  try {
    const options = await fetchFilterOptions();
    return NextResponse.json(options, {
      headers: {
        'Cache-Control': 'public, s-maxage=21600, stale-while-revalidate=3600',
      },
    });
  } catch (err) {
    console.error('[/api/schools/filters] Error:', err);
    return NextResponse.json(
      { error: 'Failed to fetch filter options' },
      { status: 500 }
    );
  }
}
